﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wfEmpregados2
{
    class EmpregadoCLT : Empregado
    {
        private double sBrutoCLT;

        public EmpregadoCLT()
        {
            sBrutoCLT = 0;
        }

        public EmpregadoCLT(String NOME, String CPF, String ENDERECO, double sBRUTOCLT) : base(NOME, CPF, ENDERECO)
        {
            sBrutoCLT = sBRUTOCLT;
        }

        public double getsBruto()
        {
            return sBrutoCLT;
        }

        public void setnHoras(double sBRUTO)
        {
            sBrutoCLT = sBRUTO;
        }

        public override double salarioLiq()
        {
            return sBrutoCLT * 0.85;
        }
    }
}
