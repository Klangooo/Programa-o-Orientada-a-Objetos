﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wfEmpregados2
{
    class EmpregadoHorista : Empregado
    {
        private double pHoras, nHoras;

        public EmpregadoHorista()
        {
            nHoras = 0;
            pHoras = 0;
        }

        public EmpregadoHorista(String NOME, String CPF, String ENDERECO, double nHORAS, double pHORAS) : base(NOME, CPF, ENDERECO)
        {
            nome = NOME;
            cpf = CPF;
            endereco = ENDERECO;
            nHoras = nHORAS;
            pHoras = pHORAS;
        }

        public double getnHoras()
        {
            return nHoras;
        }

        public void setnHoras(double nHORAS)
        {
            nHoras = nHORAS;
        }

        public double getpHoras()
        {
            return pHoras;
        }

        public void setpHoras(double pHORAS)
        {
            pHoras = pHORAS;
        }

        public override double salarioLiq()
        {
            if(nHoras*pHoras <= 5000)
            {
                return nHoras * pHoras * 0.85;
            }

            else
            {
                return nHoras * pHoras * 0.725;
            }
        }
    }
}
