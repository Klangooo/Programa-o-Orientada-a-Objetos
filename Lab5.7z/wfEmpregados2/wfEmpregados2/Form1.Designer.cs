﻿namespace wfEmpregados2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Registro = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lbCPFh = new System.Windows.Forms.Label();
            this.lbEnderecoh = new System.Windows.Forms.Label();
            this.lbNomeh = new System.Windows.Forms.Label();
            this.btOKh = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btOKclt = new System.Windows.Forms.Button();
            this.tbNomeh = new System.Windows.Forms.TextBox();
            this.tbEnderecoh = new System.Windows.Forms.TextBox();
            this.tbCPFh = new System.Windows.Forms.TextBox();
            this.tbCPFc = new System.Windows.Forms.TextBox();
            this.tbEnderecoc = new System.Windows.Forms.TextBox();
            this.tbNomec = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbNumh = new System.Windows.Forms.TextBox();
            this.tbPrecoh = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbSalariob = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.Registro.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Registro
            // 
            this.Registro.Controls.Add(this.tabPage1);
            this.Registro.Controls.Add(this.tabPage2);
            this.Registro.Controls.Add(this.tabPage3);
            this.Registro.Location = new System.Drawing.Point(-2, -1);
            this.Registro.Name = "Registro";
            this.Registro.SelectedIndex = 0;
            this.Registro.Size = new System.Drawing.Size(350, 332);
            this.Registro.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tbNumh);
            this.tabPage1.Controls.Add(this.tbPrecoh);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.tbCPFh);
            this.tabPage1.Controls.Add(this.tbEnderecoh);
            this.tabPage1.Controls.Add(this.tbNomeh);
            this.tabPage1.Controls.Add(this.lbCPFh);
            this.tabPage1.Controls.Add(this.lbEnderecoh);
            this.tabPage1.Controls.Add(this.lbNomeh);
            this.tabPage1.Controls.Add(this.btOKh);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(342, 306);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Empregado Horista";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lbCPFh
            // 
            this.lbCPFh.AutoSize = true;
            this.lbCPFh.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCPFh.Location = new System.Drawing.Point(11, 60);
            this.lbCPFh.Name = "lbCPFh";
            this.lbCPFh.Size = new System.Drawing.Size(40, 21);
            this.lbCPFh.TabIndex = 3;
            this.lbCPFh.Text = "CPF:";
            // 
            // lbEnderecoh
            // 
            this.lbEnderecoh.AutoSize = true;
            this.lbEnderecoh.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEnderecoh.Location = new System.Drawing.Point(11, 103);
            this.lbEnderecoh.Name = "lbEnderecoh";
            this.lbEnderecoh.Size = new System.Drawing.Size(77, 21);
            this.lbEnderecoh.TabIndex = 2;
            this.lbEnderecoh.Text = "Endereço:";
            // 
            // lbNomeh
            // 
            this.lbNomeh.AutoSize = true;
            this.lbNomeh.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNomeh.Location = new System.Drawing.Point(11, 20);
            this.lbNomeh.Name = "lbNomeh";
            this.lbNomeh.Size = new System.Drawing.Size(56, 21);
            this.lbNomeh.TabIndex = 1;
            this.lbNomeh.Text = "Nome:";
            // 
            // btOKh
            // 
            this.btOKh.Location = new System.Drawing.Point(261, 277);
            this.btOKh.Name = "btOKh";
            this.btOKh.Size = new System.Drawing.Size(75, 23);
            this.btOKh.TabIndex = 0;
            this.btOKh.Text = "OK";
            this.btOKh.UseVisualStyleBackColor = true;
            this.btOKh.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btOKh_MouseClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tbSalariob);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.tbCPFc);
            this.tabPage2.Controls.Add(this.tbEnderecoc);
            this.tabPage2.Controls.Add(this.tbNomec);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.btOKclt);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(342, 306);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Empregado CLT";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 21);
            this.label1.TabIndex = 6;
            this.label1.Text = "CPF:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 21);
            this.label2.TabIndex = 5;
            this.label2.Text = "Endereço:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 21);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nome:";
            // 
            // btOKclt
            // 
            this.btOKclt.Location = new System.Drawing.Point(261, 277);
            this.btOKclt.Name = "btOKclt";
            this.btOKclt.Size = new System.Drawing.Size(75, 23);
            this.btOKclt.TabIndex = 1;
            this.btOKclt.Text = "OK";
            this.btOKclt.UseVisualStyleBackColor = true;
            this.btOKclt.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btOKclt_MouseClick);
            // 
            // tbNomeh
            // 
            this.tbNomeh.Location = new System.Drawing.Point(171, 20);
            this.tbNomeh.Name = "tbNomeh";
            this.tbNomeh.Size = new System.Drawing.Size(100, 20);
            this.tbNomeh.TabIndex = 4;
            // 
            // tbEnderecoh
            // 
            this.tbEnderecoh.Location = new System.Drawing.Point(171, 103);
            this.tbEnderecoh.Name = "tbEnderecoh";
            this.tbEnderecoh.Size = new System.Drawing.Size(100, 20);
            this.tbEnderecoh.TabIndex = 5;
            // 
            // tbCPFh
            // 
            this.tbCPFh.Location = new System.Drawing.Point(171, 60);
            this.tbCPFh.Name = "tbCPFh";
            this.tbCPFh.Size = new System.Drawing.Size(100, 20);
            this.tbCPFh.TabIndex = 6;
            // 
            // tbCPFc
            // 
            this.tbCPFc.Location = new System.Drawing.Point(127, 54);
            this.tbCPFc.Name = "tbCPFc";
            this.tbCPFc.Size = new System.Drawing.Size(100, 20);
            this.tbCPFc.TabIndex = 9;
            // 
            // tbEnderecoc
            // 
            this.tbEnderecoc.Location = new System.Drawing.Point(127, 97);
            this.tbEnderecoc.Name = "tbEnderecoc";
            this.tbEnderecoc.Size = new System.Drawing.Size(100, 20);
            this.tbEnderecoc.TabIndex = 8;
            // 
            // tbNomec
            // 
            this.tbNomec.Location = new System.Drawing.Point(127, 14);
            this.tbNomec.Name = "tbNomec";
            this.tbNomec.Size = new System.Drawing.Size(100, 20);
            this.tbNomec.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(11, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 21);
            this.label4.TabIndex = 7;
            this.label4.Text = "Preco da hora:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 21);
            this.label5.TabIndex = 8;
            this.label5.Text = "Numero de horas:";
            // 
            // tbNumh
            // 
            this.tbNumh.Location = new System.Drawing.Point(171, 149);
            this.tbNumh.Name = "tbNumh";
            this.tbNumh.Size = new System.Drawing.Size(100, 20);
            this.tbNumh.TabIndex = 10;
            // 
            // tbPrecoh
            // 
            this.tbPrecoh.Location = new System.Drawing.Point(171, 192);
            this.tbPrecoh.Name = "tbPrecoh";
            this.tbPrecoh.Size = new System.Drawing.Size(100, 20);
            this.tbPrecoh.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(10, 142);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 21);
            this.label6.TabIndex = 10;
            this.label6.Text = "Salario bruto:";
            // 
            // tbSalariob
            // 
            this.tbSalariob.Location = new System.Drawing.Point(127, 142);
            this.tbSalariob.Name = "tbSalariob";
            this.tbSalariob.Size = new System.Drawing.Size(100, 20);
            this.tbSalariob.TabIndex = 11;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.listBox1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(342, 306);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Registro";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(11, 16);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(315, 277);
            this.listBox1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 328);
            this.Controls.Add(this.Registro);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Registro.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl Registro;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lbCPFh;
        private System.Windows.Forms.Label lbEnderecoh;
        private System.Windows.Forms.Label lbNomeh;
        private System.Windows.Forms.Button btOKh;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btOKclt;
        private System.Windows.Forms.TextBox tbNumh;
        private System.Windows.Forms.TextBox tbPrecoh;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbCPFh;
        private System.Windows.Forms.TextBox tbEnderecoh;
        private System.Windows.Forms.TextBox tbNomeh;
        private System.Windows.Forms.TextBox tbSalariob;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbCPFc;
        private System.Windows.Forms.TextBox tbEnderecoc;
        private System.Windows.Forms.TextBox tbNomec;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ListBox listBox1;
    }
}

