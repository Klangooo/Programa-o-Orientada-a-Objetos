﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wfEmpregados2
{
    public partial class Form1 : Form
    {
        List<EmpregadoHorista> listaEmpregadoHorista = new List<EmpregadoHorista>();
        List<EmpregadoCLT> listaEmpregadoCLT = new List<EmpregadoCLT>();
        string _cpf, _nome, _endereco;
        double _valorh, _salariob, _numh;

        public Form1()
        {
            InitializeComponent();
        }

        private void btOKclt_MouseClick(object sender, MouseEventArgs e)
        {
            _cpf = Convert.ToString(tbCPFc.Text);
            _nome = Convert.ToString(tbNomec.Text);
            _endereco = Convert.ToString(tbEnderecoc.Text);
            _salariob = Convert.ToDouble(tbSalariob.Text);
            EmpregadoCLT c = new EmpregadoCLT(_nome, _cpf, _endereco, _salariob);
            listaEmpregadoCLT.Add(c);
            tbCPFc.Clear();
            tbEnderecoc.Clear();
            tbNomec.Clear();
            tbSalariob.Clear();
            listBox1.Items.Add(c.getNome());
            listBox1.Items.Add(c.salarioLiq());
        }

        private void btOKh_MouseClick(object sender, MouseEventArgs e)
        {
            _cpf = Convert.ToString(tbCPFh.Text);
            _nome = Convert.ToString(tbNomeh.Text);
            _endereco = Convert.ToString(tbEnderecoh.Text);
            _numh = Convert.ToDouble(tbNumh.Text);
            _valorh = Convert.ToDouble(tbPrecoh.Text);
            EmpregadoHorista h = new EmpregadoHorista(_nome, _cpf, _endereco, _numh, _valorh);
            listaEmpregadoHorista.Add(h);
            tbCPFh.Clear();
            tbEnderecoh.Clear();
            tbNomeh.Clear();
            tbNumh.Clear();
            tbPrecoh.Clear();
            listBox1.Items.Add(h.getNome());
            listBox1.Items.Add(h.salarioLiq());
        }
    }
}
