﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wfEmpregados2
{
    abstract class Empregado
    {
        protected String nome, cpf, endereco;

        public Empregado()
        {
            nome = " ";
            cpf = " ";
            endereco = " ";
        }

        public Empregado(string NOME, string CPF, string ENDERECO)
        {
            cpf = CPF;
            nome = NOME;
            endereco = ENDERECO;
        }
        
        public string getCpf()
        {
            return cpf;
        }

        public void setCpf(String CPF)
        {
            cpf = CPF;
        }

        public string getEndereco()
        {
            return endereco;
        }

        public void setEndereco(String ENDERECO)
        {
            endereco = ENDERECO;
        }

        public String getNome()
        {
            return nome;
        }

        public void setNome(String NOME)
        {
            nome = NOME;
        }

        public abstract double salarioLiq();
    }
}
