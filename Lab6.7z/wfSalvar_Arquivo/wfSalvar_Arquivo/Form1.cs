﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace wfSalvar_Arquivo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        string texto, nomeArquivo;

        private void btAbrir_MouseClick(object sender, MouseEventArgs e)
        {
            tbxTexto.Clear();
            nomeArquivo = tbxDoc.Text;

            if (File.Exists(nomeArquivo))
            {
                try
                {
                    StreamReader leitor = new StreamReader(nomeArquivo);
                    texto = leitor.ReadToEnd();
                    tbxTexto.Text = texto;
                    leitor.Close();
                    btSalvar.Visible = true;
                }
                catch (IOException)
                {
                    MessageBox.Show("Erro de Arquivo", "Erro de Arquivo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            else if (Directory.Exists(nomeArquivo))
            {
                string[] directoryList;

                directoryList = Directory.GetDirectories(nomeArquivo);

                tbxTexto.Text +=
                   "Conteúdo do diretório:\r\n";

                for (int i = 0; i < directoryList.Length; i++)
                    tbxTexto.Text += directoryList[i] + "\r\n";
            }
            else
            {
                MessageBox.Show(tbxDoc.Text +
                   " não existe", "Erro de Arquivo",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        MouseEventArgs aux;

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Salvar Arquivo?", "Salvar Arquivo?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                btSalvar_MouseClick(sender, aux);
            }
            else
            {
                Application.ExitThread();
            }
        }

        private void btSalvar_MouseClick(object sender, MouseEventArgs e)
        {
            texto = tbxTexto.Text;
            try
            {
                StreamWriter escritor = new StreamWriter(@nomeArquivo);
                escritor.WriteLine(texto);
                escritor.Dispose();
                MessageBox.Show("Arquivo Salvo", "Arquivo Salvo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            catch(IOException)
            {
                MessageBox.Show("Erro de Arquivo", "Erro de Arquivo",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
