﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Vetor3D : Vetor2D
    {
        private double z;

        public Vetor3D()
        {
            z = 0;
        }

        public Vetor3D(double X, double Y, double Z) : base(X, Y)
        {
            z = Z;
        }

        public double getZ()
        {
            return z;
        }

        public void setZ(double Z)
        {
            z = Z;
        }
    }
}
