﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Vetor2D
    {
        double x;
        double y;

        public Vetor2D()
        {
            x = 0;
            y = 0;
        }

        public Vetor2D(double X, double Y)
        {
            x = X;
            y = Y;
        }

        public double getX()
        {
            return x;
        }

        public void setX(double X)
        {
            x = X;
        }

        public double getY()
        {
            return y;
        }

        public void setY(double Y)
        {
            y = Y;
        }
    }
}
