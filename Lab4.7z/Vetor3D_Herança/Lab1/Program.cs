﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static double produto_escalarVetor(double x1, double y1, double z1, double x2, double y2, double z2)
        {
            double resposta;
            resposta = x1 * x2 + y1 * y2 + z1 * z2;
            return resposta;
        }

        static double moduloVetor(double x1, double y1, double z1)
        {
            double resposta;
            resposta = Math.Sqrt(Math.Pow(x1, 2) + Math.Pow(y1, 2) + Math.Pow(z1, 2));
            return resposta;
        }

        static void Main(string[] args)
        {
            double X, Y, Z;

            Console.WriteLine("Digite o vetor 1:\n");
            Console.Write("\nX: ");
            X = Convert.ToDouble(Console.ReadLine());
            Console.Write("\nY: ");
            Y = Convert.ToDouble(Console.ReadLine());
            Console.Write("\nZ: ");
            Z = Convert.ToDouble(Console.ReadLine());

            Vetor3D vet1 = new Vetor3D(X, Y, Z);
            Console.Clear();

            Console.Write("Digite o vetor 2:\n");
            Console.Write("\nX: ");
            X = Convert.ToDouble(Console.ReadLine());
            Console.Write("\nY: ");
            Y = Convert.ToDouble(Console.ReadLine());
            Console.Write("\nZ: ");
            Z = Convert.ToDouble(Console.ReadLine());

            Vetor3D vet2 = new Vetor3D(X, Y, Z);
            Console.Clear();

            double resProdEscalar;
            resProdEscalar = produto_escalarVetor(vet1.getX(), vet1.getY(), vet1.getZ(), vet2.getX(), vet2.getY(), vet2.getZ());

            double resModulo1, resModulo2;
            resModulo1 = moduloVetor(vet1.getX(), vet1.getY(), vet1.getZ());
            resModulo2 = moduloVetor(vet1.getX(), vet1.getY(), vet1.getZ());

            Console.WriteLine("Produto escalar: " + Convert.ToString(resProdEscalar));
            Console.WriteLine("Modulo vetor 1: " + Convert.ToString(resModulo1));
            Console.WriteLine("Modulo vetor 2: " + Convert.ToString(resModulo2));
            Console.ReadLine();
        }
    }
}
