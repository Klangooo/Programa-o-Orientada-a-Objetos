﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caListaPilhaFila
{
    class Program
    {
        static int menu()
        {
            int op;
            Console.Clear();
            Console.WriteLine("Escolha uma das opções:\n" + "1)Criar uma lista de inteiros\n" + "2)Criar uma fila de inteiros\n" + "3)Criar uma pilha de inteiros\n" +"4)Sair\n");
            try
            {
                op = int.Parse(Console.ReadLine());
            }
            catch (Exception)
            {
                op = 0;
            }

            return op;
        }

        static int altMenu(string dataType)
        {
            int op;
            Console.Clear();
            switch (dataType)
            {
                case "lista":
                    Console.WriteLine("1) Inserire um inteiro no início da lista\n" + "2) Inserire um inteiro no fim da lista\n" + "3) Remove um inteiro da lista\n" + "4) Imprime a lista\n" + "5) Voltar\n");
                    break;
                case "pilha":
                    Console.WriteLine("1) Insire um inteiro na pilha\n" + "2) Remove um inteiro da pilha\n" + "3) Imprime a pilha\n" + "4) Voltar\n");
                    break;
                case "fila":
                    Console.WriteLine("1) Insire um inteiro na fila\n" + "2) Remove um inteiro da fila\n" + "3) Imprime a fila\n" + "4) Voltar\n");
                    break;
                default:
                    break;
            }
            try
            {
                op = int.Parse(Console.ReadLine());
            }
            catch (Exception)
            {
                op = 0;
            }

            return op;
        }

        static void Main(string[] args)
        {
            bool sair = false;
            Lista<int> lista = new Lista<int>();
            Pilha<int> pilha = new Pilha<int>();
            Fila<int> fila = new Fila<int>();

            while (!sair)
            {
                bool voltar = false;

                switch (menu())
                {
                    case 1:
                        lista = new Lista<int>();
                        while (!voltar)
                        {
                            switch (altMenu("lista"))
                            {
                                case 1:
                                    Console.Write("Digite um número inteiro: ");
                                    try
                                    {
                                        lista.insereInicio(int.Parse(Console.ReadLine()));
                                        Console.WriteLine("Número inserido!");
                                    }
                                    catch (Exception)
                                    {
                                        Console.Error.WriteLine("Erro ao inserir número!");
                                    }
                                    Console.ReadLine();
                                    break;
                                case 2:
                                    Console.Write("Digite um número inteiro: ");
                                    try
                                    {
                                        lista.insereFim(int.Parse(Console.ReadLine()));
                                        Console.WriteLine("Número inserido!");
                                    }
                                    catch (Exception)
                                    {
                                        Console.Error.WriteLine("Erro ao inserir número!");
                                    }
                                    Console.ReadLine();
                                    break;
                                case 3:
                                    lista.imprimeED();
                                    Console.WriteLine("Qual número deseja remover?");
                                    try
                                    {
                                        lista.remove(int.Parse(Console.ReadLine()));
                                        Console.WriteLine("Número removido!");
                                    }
                                    catch (Exception)
                                    {
                                        Console.Error.WriteLine("Erro ao remover número!");
                                    }
                                    finally
                                    {
                                        Console.ReadLine();
                                    }
                                    break;
                                case 4:
                                    lista.imprimeED();
                                    Console.ReadLine();
                                    break;
                                case 5:
                                    voltar = true;
                                    break;
                                default:
                                    break;
                            }
                        }
                        break;
                    case 2:
                        fila = new Fila<int>();
                        while (!voltar)
                        {
                            switch (altMenu("fila"))
                            {
                                case 1:
                                    Console.WriteLine("Digite um número inteiro: ");
                                    try
                                    {
                                        fila.insereInicio(int.Parse(Console.ReadLine()));
                                        Console.WriteLine("Número inserido!");
                                    }
                                    catch (Exception)
                                    {
                                        Console.Error.WriteLine("Erro ao inserir número!");
                                    }
                                    Console.ReadLine();
                                    break;
                                case 2:
                                    try
                                    {
                                        Console.WriteLine("Número removido :" + fila.removeFim());
                                    }
                                    catch (Exception)
                                    {
                                        Console.Error.WriteLine("Erro ao remover número!");
                                    }
                                    finally
                                    {
                                        Console.ReadLine();
                                    }
                                    break;
                                case 3:
                                    fila.imprime();
                                    Console.ReadLine();
                                    break;
                                case 4:
                                    voltar = true;
                                    break;
                                default:
                                    break;
                            }
                        }
                        break;
                    case 3:
                        pilha = new Pilha<int>();
                        while (!voltar)
                        {
                            switch (altMenu("pilha"))
                            {
                                case 1:
                                    Console.WriteLine("Digite um número inteiro: ");
                                    try
                                    {
                                        pilha.insereInicio(int.Parse(Console.ReadLine()));
                                        Console.WriteLine("Número inserido!");
                                    }
                                    catch (Exception)
                                    {
                                        Console.Error.WriteLine("Erro ao inserir número!");
                                    }
                                    Console.ReadLine();
                                    break;
                                case 2:
                                    try
                                    {
                                        Console.WriteLine("Número removido :" + pilha.removeInicio());
                                    }
                                    catch (Exception)
                                    {
                                        Console.Error.WriteLine("Erro ao remover número!");
                                    }
                                    finally
                                    {
                                        Console.ReadLine();
                                    }
                                    break;
                                case 3:
                                    pilha.imprime();
                                    Console.ReadLine();
                                    break;
                                case 4:
                                    voltar = true;
                                    break;
                                default:
                                    break;
                            }
                        }
                        break;
                    case 4:
                        lista.imprimeED();
                        fila.imprime();
                        pilha.imprime();
                        Console.ReadLine();
                        sair = true;
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
