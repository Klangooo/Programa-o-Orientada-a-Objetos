﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        static Aluno achaAluno(String nome_aluno, List<Aluno> alunos)
        {
            Aluno achei_aluno = null;
            for (int i = 0; i < alunos.Count(); i++)
            {
                if (nome_aluno == alunos[i].getNome())
                {
                    achei_aluno = alunos[i];
                    break;
                }
            }
            return achei_aluno;
        }

        static Materia achaMateria(String nome_materia, List<Materia> materias)
        {
            Materia achei_materia = null;

            for (int i = 0; i < materias.Count(); i++)
            {
                if (nome_materia == materias[i].Nome)
                {
                    achei_materia = materias[i];
                    break;
                }
            }
            return achei_materia;
        }
        
        public Form1()
        {
            InitializeComponent();
        }

        String nome_aluno, nome_materia;

        Aluno aL;
        Materia mL;

        List<Aluno> listaAlunos = new List<Aluno>();
        List<Materia> listaMaterias = new List<Materia>();

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btOK1_MouseClick(object sender, MouseEventArgs e)
        {
            Aluno a = new Aluno(tbNomeAluno.Text, tbMatricula.Text, tbPeriodo.Text);
            listaAlunos.Add(a);
            lbAlunos.Items.Add(tbNomeAluno.Text);
            lbRegistro.Items.Add(tbNomeAluno.Text);
            tbNomeAluno.Clear();
            tbMatricula.Clear();
            tbPeriodo.Clear();
        }

        private void btOK2_MouseClick(object sender, MouseEventArgs e)
        {
            Materia m = new Materia(tbNomeMateria.Text, tbCodigo.Text);
            listaMaterias.Add(m);
            lbMaterias.Items.Add(tbNomeMateria.Text);
            tbNomeMateria.Clear();
            tbCodigo.Clear();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btOK1_Click(object sender, EventArgs e)
        {

        }

        private void lbMaterias_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btOK4_MouseClick(object sender, MouseEventArgs e)
        {
            nome_aluno = lbRegistro.SelectedItem.ToString();
            aL = achaAluno(nome_aluno, listaAlunos);
            lbRegistroMat.Items.Add(colocaMateria(aL));

        }

        private void btOK3_MouseClick(object sender, MouseEventArgs e)
        {
            nome_aluno = tbAssAl.Text;
            aL = achaAluno(nome_aluno, listaAlunos);
            nome_materia = tbAssMl.Text;
            mL = achaMateria(nome_materia, listaMaterias);
            aL.associaMateria(mL);
            tbAssAl.Clear();
            tbAssMl.Clear();
            
        }
       
    }
}
