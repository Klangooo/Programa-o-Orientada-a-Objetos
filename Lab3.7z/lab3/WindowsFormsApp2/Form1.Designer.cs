﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbNomeMateria = new System.Windows.Forms.TextBox();
            this.tbCodigo = new System.Windows.Forms.TextBox();
            this.btOK2 = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbNomeAluno = new System.Windows.Forms.TextBox();
            this.tbPeriodo = new System.Windows.Forms.TextBox();
            this.tbMatricula = new System.Windows.Forms.TextBox();
            this.btOK1 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.lbAlunos = new System.Windows.Forms.ListBox();
            this.lbMaterias = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbAssMl = new System.Windows.Forms.TextBox();
            this.tbAssAl = new System.Windows.Forms.TextBox();
            this.btOK3 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btOK4 = new System.Windows.Forms.Button();
            this.lbRegistro = new System.Windows.Forms.ListBox();
            this.lbRegistroMat = new System.Windows.Forms.ListBox();
            this.tabPage4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btOK3);
            this.tabPage4.Controls.Add(this.tbAssAl);
            this.tabPage4.Controls.Add(this.tbAssMl);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.label6);
            this.tabPage4.Controls.Add(this.lbMaterias);
            this.tabPage4.Controls.Add(this.lbAlunos);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(427, 272);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Associa";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btOK2);
            this.tabPage2.Controls.Add(this.tbCodigo);
            this.tabPage2.Controls.Add(this.tbNomeMateria);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(427, 272);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Matricula";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(13, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "Nome:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Codigo:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // tbNomeMateria
            // 
            this.tbNomeMateria.Location = new System.Drawing.Point(106, 46);
            this.tbNomeMateria.Name = "tbNomeMateria";
            this.tbNomeMateria.Size = new System.Drawing.Size(100, 20);
            this.tbNomeMateria.TabIndex = 6;
            // 
            // tbCodigo
            // 
            this.tbCodigo.Location = new System.Drawing.Point(106, 102);
            this.tbCodigo.Name = "tbCodigo";
            this.tbCodigo.Size = new System.Drawing.Size(100, 20);
            this.tbCodigo.TabIndex = 7;
            // 
            // btOK2
            // 
            this.btOK2.Location = new System.Drawing.Point(291, 232);
            this.btOK2.Name = "btOK2";
            this.btOK2.Size = new System.Drawing.Size(75, 23);
            this.btOK2.TabIndex = 8;
            this.btOK2.Text = "OK";
            this.btOK2.UseVisualStyleBackColor = true;
            this.btOK2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btOK2_MouseClick);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btOK1);
            this.tabPage1.Controls.Add(this.tbMatricula);
            this.tabPage1.Controls.Add(this.tbPeriodo);
            this.tabPage1.Controls.Add(this.tbNomeAluno);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(427, 272);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Aluno";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 176);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Periodo:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Matricula:";
            // 
            // tbNomeAluno
            // 
            this.tbNomeAluno.Location = new System.Drawing.Point(138, 47);
            this.tbNomeAluno.Name = "tbNomeAluno";
            this.tbNomeAluno.Size = new System.Drawing.Size(100, 20);
            this.tbNomeAluno.TabIndex = 3;
            // 
            // tbPeriodo
            // 
            this.tbPeriodo.Location = new System.Drawing.Point(138, 176);
            this.tbPeriodo.Name = "tbPeriodo";
            this.tbPeriodo.Size = new System.Drawing.Size(100, 20);
            this.tbPeriodo.TabIndex = 4;
            // 
            // tbMatricula
            // 
            this.tbMatricula.Location = new System.Drawing.Point(138, 103);
            this.tbMatricula.Name = "tbMatricula";
            this.tbMatricula.Size = new System.Drawing.Size(100, 20);
            this.tbMatricula.TabIndex = 5;
            // 
            // btOK1
            // 
            this.btOK1.Location = new System.Drawing.Point(291, 232);
            this.btOK1.Name = "btOK1";
            this.btOK1.Size = new System.Drawing.Size(75, 23);
            this.btOK1.TabIndex = 6;
            this.btOK1.Text = "OK";
            this.btOK1.UseVisualStyleBackColor = true;
            this.btOK1.Click += new System.EventHandler(this.btOK1_Click);
            this.btOK1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btOK1_MouseClick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(-5, -3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(435, 298);
            this.tabControl1.TabIndex = 0;
            // 
            // lbAlunos
            // 
            this.lbAlunos.FormattingEnabled = true;
            this.lbAlunos.Location = new System.Drawing.Point(6, 6);
            this.lbAlunos.Name = "lbAlunos";
            this.lbAlunos.Size = new System.Drawing.Size(120, 147);
            this.lbAlunos.TabIndex = 0;
            // 
            // lbMaterias
            // 
            this.lbMaterias.FormattingEnabled = true;
            this.lbMaterias.Location = new System.Drawing.Point(246, 6);
            this.lbMaterias.Name = "lbMaterias";
            this.lbMaterias.Size = new System.Drawing.Size(120, 147);
            this.lbMaterias.TabIndex = 1;
            this.lbMaterias.SelectedIndexChanged += new System.EventHandler(this.lbMaterias_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(2, 206);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "Aluno:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(194, 206);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "Materia:";
            // 
            // tbAssMl
            // 
            this.tbAssMl.Location = new System.Drawing.Point(266, 206);
            this.tbAssMl.Name = "tbAssMl";
            this.tbAssMl.Size = new System.Drawing.Size(100, 20);
            this.tbAssMl.TabIndex = 7;
            // 
            // tbAssAl
            // 
            this.tbAssAl.Location = new System.Drawing.Point(63, 206);
            this.tbAssAl.Name = "tbAssAl";
            this.tbAssAl.Size = new System.Drawing.Size(100, 20);
            this.tbAssAl.TabIndex = 8;
            // 
            // btOK3
            // 
            this.btOK3.Location = new System.Drawing.Point(302, 243);
            this.btOK3.Name = "btOK3";
            this.btOK3.Size = new System.Drawing.Size(75, 23);
            this.btOK3.TabIndex = 9;
            this.btOK3.Text = "Associar";
            this.btOK3.UseVisualStyleBackColor = true;
            this.btOK3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btOK3_MouseClick);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lbRegistroMat);
            this.tabPage3.Controls.Add(this.lbRegistro);
            this.tabPage3.Controls.Add(this.btOK4);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(427, 272);
            this.tabPage3.TabIndex = 4;
            this.tabPage3.Text = "Registro";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btOK4
            // 
            this.btOK4.Location = new System.Drawing.Point(291, 232);
            this.btOK4.Name = "btOK4";
            this.btOK4.Size = new System.Drawing.Size(75, 23);
            this.btOK4.TabIndex = 0;
            this.btOK4.Text = "OK";
            this.btOK4.UseVisualStyleBackColor = true;
            this.btOK4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btOK4_MouseClick);
            // 
            // lbRegistro
            // 
            this.lbRegistro.FormattingEnabled = true;
            this.lbRegistro.Location = new System.Drawing.Point(6, 6);
            this.lbRegistro.Name = "lbRegistro";
            this.lbRegistro.Size = new System.Drawing.Size(120, 238);
            this.lbRegistro.TabIndex = 1;
            // 
            // lbRegistroMat
            // 
            this.lbRegistroMat.FormattingEnabled = true;
            this.lbRegistroMat.Location = new System.Drawing.Point(246, 6);
            this.lbRegistroMat.Name = "lbRegistroMat";
            this.lbRegistroMat.Size = new System.Drawing.Size(120, 186);
            this.lbRegistroMat.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(377, 286);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ListBox lbAlunos;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btOK2;
        private System.Windows.Forms.TextBox tbCodigo;
        private System.Windows.Forms.TextBox tbNomeMateria;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btOK1;
        private System.Windows.Forms.TextBox tbMatricula;
        private System.Windows.Forms.TextBox tbPeriodo;
        private System.Windows.Forms.TextBox tbNomeAluno;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.ListBox lbMaterias;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbAssAl;
        private System.Windows.Forms.TextBox tbAssMl;
        private System.Windows.Forms.Button btOK3;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ListBox lbRegistro;
        private System.Windows.Forms.Button btOK4;
        private System.Windows.Forms.ListBox lbRegistroMat;
    }
}

