﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wfPilhaDeInteiros
{
    class Pilha
    {
        // atributos 
        private NohPilha topo;

        // metodos
        public Pilha()
        {
            topo = null; // não foi inserido elemento
        }

        public bool isEmpty()
        {
            if (topo == null)
                return true;
            else
                return false;
        }

        public void push(int insertItem)
        {
            if (isEmpty())
                topo = new NohPilha(insertItem);
            else
            {
                NohPilha novoNoh = new NohPilha(insertItem, topo);
                topo = novoNoh; // o topo agora aponta para mim -- this
            }
        } // fim do método push

        public int achaMaior()
        {
            int temp = 0;
            NohPilha topo2;
            topo2 = topo;
            while (topo2 != null)
            {
                if (topo2.getData() > temp)
                {
                    temp = topo2.getData();
                }

                else
                {
                    topo2.getNext();
                }
                    
            }
            return temp;
        }

        public int print()
        {
            NohPilha temp = topo;
            return temp.getData();
        } // fim do método print

       // public string pop(int num)
        //{
         //   if (isEmpty())
          //  {
           //     topo = null;
            //    return "Pilha vazia!";
            //}

            //else
            //{
                //topo2 = topo;

               // NohPilha temp = new NohPilha(num);
                //while(temp != topo2)
             //   {
                //    push(topo2.getData());
                //    topo2.getNext();
               // }
                //return topo.ToString();
            //}
        //}

    } // fim da classe Pilha
}