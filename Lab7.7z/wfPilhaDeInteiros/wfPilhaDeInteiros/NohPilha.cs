﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wfPilhaDeInteiros
{
    class NohPilha
    {
        // atributos
        private int data;
        private NohPilha nextNoh; // autoreferencia

        // metodos 
        public NohPilha()
        {
            nextNoh = null;
        }

        public NohPilha(int valor)
        {
            data = valor;
            nextNoh = null;
        }

        public NohPilha(int valor, NohPilha noh)
        {
            data = valor;
            nextNoh = noh;
        }

        public int getData()
        {
            return data;
        }

        public void setData(int valor)
        {
            data = valor;
        }

        public NohPilha getNext()
        {
            return nextNoh;
        }

        public void setNext(NohPilha newNoh)
        {
            nextNoh = newNoh;
        }

    } // fim da classe NohPilha
}
