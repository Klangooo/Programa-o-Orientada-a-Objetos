﻿namespace wfPilhaDeInteiros
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btPush = new System.Windows.Forms.Button();
            this.btPop = new System.Windows.Forms.Button();
            this.btImprime = new System.Windows.Forms.Button();
            this.btMaior = new System.Windows.Forms.Button();
            this.btMenor = new System.Windows.Forms.Button();
            this.btInverte = new System.Windows.Forms.Button();
            this.nmPush = new System.Windows.Forms.NumericUpDown();
            this.nmPop = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.rtbPilha = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nmPush)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmPop)).BeginInit();
            this.SuspendLayout();
            // 
            // btPush
            // 
            this.btPush.Location = new System.Drawing.Point(177, 43);
            this.btPush.Name = "btPush";
            this.btPush.Size = new System.Drawing.Size(75, 23);
            this.btPush.TabIndex = 0;
            this.btPush.Text = "PUSH";
            this.btPush.UseVisualStyleBackColor = true;
            this.btPush.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btPush_MouseClick);
            // 
            // btPop
            // 
            this.btPop.Location = new System.Drawing.Point(177, 87);
            this.btPop.Name = "btPop";
            this.btPop.Size = new System.Drawing.Size(75, 23);
            this.btPop.TabIndex = 1;
            this.btPop.Text = "POP\r\n";
            this.btPop.UseVisualStyleBackColor = true;
            this.btPop.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btPop_MouseClick);
            // 
            // btImprime
            // 
            this.btImprime.Location = new System.Drawing.Point(177, 131);
            this.btImprime.Name = "btImprime";
            this.btImprime.Size = new System.Drawing.Size(75, 23);
            this.btImprime.TabIndex = 2;
            this.btImprime.Text = "IMPRIME";
            this.btImprime.UseVisualStyleBackColor = true;
            this.btImprime.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btImprime_MouseClick);
            // 
            // btMaior
            // 
            this.btMaior.Location = new System.Drawing.Point(177, 175);
            this.btMaior.Name = "btMaior";
            this.btMaior.Size = new System.Drawing.Size(75, 23);
            this.btMaior.TabIndex = 3;
            this.btMaior.Text = "MAIOR";
            this.btMaior.UseVisualStyleBackColor = true;
            // 
            // btMenor
            // 
            this.btMenor.Location = new System.Drawing.Point(177, 219);
            this.btMenor.Name = "btMenor";
            this.btMenor.Size = new System.Drawing.Size(75, 23);
            this.btMenor.TabIndex = 4;
            this.btMenor.Text = "MENOR";
            this.btMenor.UseVisualStyleBackColor = true;
            // 
            // btInverte
            // 
            this.btInverte.Location = new System.Drawing.Point(177, 263);
            this.btInverte.Name = "btInverte";
            this.btInverte.Size = new System.Drawing.Size(75, 23);
            this.btInverte.TabIndex = 5;
            this.btInverte.Text = "INVERTE";
            this.btInverte.UseVisualStyleBackColor = true;
            // 
            // nmPush
            // 
            this.nmPush.Location = new System.Drawing.Point(258, 43);
            this.nmPush.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.nmPush.Minimum = new decimal(new int[] {
            999999,
            0,
            0,
            -2147483648});
            this.nmPush.Name = "nmPush";
            this.nmPush.Size = new System.Drawing.Size(91, 20);
            this.nmPush.TabIndex = 6;
            this.nmPush.ThousandsSeparator = true;
            // 
            // nmPop
            // 
            this.nmPop.Location = new System.Drawing.Point(258, 87);
            this.nmPop.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.nmPop.Minimum = new decimal(new int[] {
            999999,
            0,
            0,
            -2147483648});
            this.nmPop.Name = "nmPop";
            this.nmPop.Size = new System.Drawing.Size(91, 20);
            this.nmPop.TabIndex = 7;
            this.nmPop.ThousandsSeparator = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(13, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Pilha:";
            // 
            // rtbPilha
            // 
            this.rtbPilha.Location = new System.Drawing.Point(66, 43);
            this.rtbPilha.Name = "rtbPilha";
            this.rtbPilha.ReadOnly = true;
            this.rtbPilha.Size = new System.Drawing.Size(100, 243);
            this.rtbPilha.TabIndex = 9;
            this.rtbPilha.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(353, 307);
            this.Controls.Add(this.rtbPilha);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nmPop);
            this.Controls.Add(this.nmPush);
            this.Controls.Add(this.btInverte);
            this.Controls.Add(this.btMenor);
            this.Controls.Add(this.btMaior);
            this.Controls.Add(this.btImprime);
            this.Controls.Add(this.btPop);
            this.Controls.Add(this.btPush);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nmPush)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmPop)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btPush;
        private System.Windows.Forms.Button btPop;
        private System.Windows.Forms.Button btImprime;
        private System.Windows.Forms.Button btMaior;
        private System.Windows.Forms.Button btMenor;
        private System.Windows.Forms.Button btInverte;
        private System.Windows.Forms.NumericUpDown nmPush;
        private System.Windows.Forms.NumericUpDown nmPop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox rtbPilha;
    }
}

