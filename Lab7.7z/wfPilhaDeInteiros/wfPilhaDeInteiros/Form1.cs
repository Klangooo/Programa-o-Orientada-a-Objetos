﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wfPilhaDeInteiros
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Pilha pInt = new Pilha();

        private void btPush_MouseClick(object sender, MouseEventArgs e)
        {
            int num;
            num = Convert.ToInt32(nmPush.Value);
            pInt.push(num);
            rtbPilha.Text = pInt.print() + "\n" + rtbPilha.Text;
        }

        private void btPop_MouseClick(object sender, MouseEventArgs e)
        {
            /* int num;
             num = Convert.ToInt32(nmPop.Value);

             string topo;
             topo = pInt.pop(num);

             if(topo == "Pilha vazia!")
             {
                 rtbPilha.Clear();
                 rtbPilha.Text = "Pilha vazia!";
             }

             else
             {
                 rtbPilha.Clear();
                 rtbPilha.Text = topo.ToString();

             }*/
        }

        private void btImprime_MouseClick(object sender, MouseEventArgs e)
        {
            int maiorNum;
            Pilha pAux = new Pilha();
            pAux = pInt;
            maiorNum = pAux.achaMaior();
            rtbPilha.Clear();
            rtbPilha.Text = "Maior numero: " + "\n" + maiorNum;
        }
    }
}
